// types/daisyui.d.ts
declare module "daisyui";
